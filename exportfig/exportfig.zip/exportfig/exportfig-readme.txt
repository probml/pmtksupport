%PMTKauthor Ben Hinkle
%PMTKurl http://www.mathworks.com/matlabcentral/fileexchange/727
%PMTKtitle exportfig: makes figures suitable for inclusion in publications 