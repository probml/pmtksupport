%PMTKtitle glmnet: L1/L2 regularization paths for linear/logistic regression
%PMTKauthor  Jerome Friedman, Trevor Hastie, Rob Tibshirani,  Hui Jiang
%PMTKurl http://www-stat.stanford.edu/~tibs/glmnet-matlab/
%PMTKdate 14 Jul 2009

