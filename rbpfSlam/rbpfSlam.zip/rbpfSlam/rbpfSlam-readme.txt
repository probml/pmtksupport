%PMTKtitle rbpfSlam: Rao-Blackwellised particle filtering for SLAM
%PMTKauthor James Cook, Iryna Skrypnyk, and Roland Wenzel


