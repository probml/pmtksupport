%PMTKtitle dpMixWood: Dirichlet process mixture models
%PMTKurl http://www.stat.columbia.edu/~fwood/Code/dpm_spike_sorter_0_1.zip
%PMTKauthor Frank Wood
%PMTKdate 2009
