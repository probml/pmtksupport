function l = length(m)
% DIRICHLET/LENGTH returns the number of categories or multinomial states

l = length(m.alpha);

