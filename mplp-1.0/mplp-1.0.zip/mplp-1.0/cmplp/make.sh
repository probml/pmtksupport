g++ -O3 mplp_alg.cpp mplp_main.cpp muldim_arr.cpp 
cp a.out  ../mplp/.
