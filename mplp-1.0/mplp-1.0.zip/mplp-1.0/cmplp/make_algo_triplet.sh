g++ -O3 mplp_alg.cpp tighten_main.cpp muldim_arr.cpp 
mv a.out algo_triplet
mv algo_triplet ../mplp/.
