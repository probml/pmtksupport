cd cmplp
./make_algo_triplet.sh
cd ..