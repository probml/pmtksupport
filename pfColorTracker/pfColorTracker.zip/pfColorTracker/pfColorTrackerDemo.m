% Call existing demo
test_pf_colortracker
