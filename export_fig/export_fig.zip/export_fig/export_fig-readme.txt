
%PMTKtitle Export_fig:  makes figures suitable for inclusion in publications
%PMTKauthor Oliver Woodford
%PMTKdate 2008-2009
%PMTKurl http://www.mathworks.com/matlabcentral/fileexchange/23629
