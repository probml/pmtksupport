#include "matrix.h"
double Isampling(double** suffdata, mwSize size, int* vert, double delta, double tau,int** A, mwSize N);
