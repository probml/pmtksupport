#include "matrix.h"
double likecomb(Graph *graph,double ** suffdat,  double tau, double delta);
mwSize complete(mwSize ** incidence, mwSize * vertices, mwSize nvertices);
double cliquelike(mwSize *vertices, mwSize nvertices,double ** suffdat, double tau, double delta);
