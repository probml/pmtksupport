void Add(LPGraph graph, int*  edge);
void remove(LPGraph graph, int*  edge);
int * rand_edge_add(LPGraph graph, int current_edges, int total_edges);
int * rand_edge_delete(LPGraph graph, int current_edges);
