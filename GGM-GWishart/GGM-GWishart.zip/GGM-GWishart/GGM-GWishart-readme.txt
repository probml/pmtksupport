%PMTKtitle GGM-GWishart: Marginal likelihood for non-decomposable Gaussian graphical models using G-Wishart prior (MC, Laplace and BIC approximations)
%PMTKauthor Ben Marlin, Kevin Murphy, Mark Schmidt, Baback Moghaddam, Beatrix Jones, Carlos Carvalho, Adrian Dobra, Chris Hans, Chris Carter, Mike West  
%PMTKurl http://people.cs.ubc.ca/~bmarlin/code/code-ggmgwishart.shtml
%PMTKdate 24 June 2010
