%PMTKtitle rjmcmcRbf: Reversible jump MCMC for RBF regression
%PMTKauthor Nando de Freitas
%PMTKurl http://people.cs.ubc.ca/~nando/software/rjMCMC.tar
%PMTKdate 2001


