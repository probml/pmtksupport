%PMTKtitle VBlinlogreg: Variational Bayes for linear and logistic regression
%PMTKauthor Jan Drugowitsch
%PMTKurl http://www.bcs.rochester.edu/people/jdrugowitsch/code.html
%PMTKdate May 2010 (version 0.1.2)
