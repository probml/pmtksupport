%PMTKtitle MaxBranching: Compute maximal branching of a graph (Edmonds algorithm)
%PMTKauthor Ashish Choudhary
%PMTKurl http://www.mathworks.com/matlabcentral/fileexchange/24899
%PMTKdate 1 August 2009


