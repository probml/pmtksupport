%PMTKauthor Mark Schmidt
%PMTKurl http://www.cs.ubc.ca/~schmidtm/Software/code.html
%PMTKdate 9 March 2011
%PMTKtitle Various optimization and machine learning packages
