%PMTKtitle onlineEM: demos of online EM for mixtures of poisson and mix regression
%PMTKauthor Olivier Cappe
%PMTKdate 25 June 2010
See "Online EM Algorithm for Latent Data Models", JRSSB 2009
