%PMTKtitle Lars: Methods for L2 regularized linear regression and Elastic net
%PMTKauthor Karl Skoglund
%PMTKurl http://www2.imm.dtu.dk/pubdb/views/publication_details.php?id=3897


