%PMTKtitle BPCA: Variational Bayes for PCA, handles missing data
%PMTKurl  http://hawaii.sys.i.kyoto-u.ac.jp/~oba/tools/
%PMTKauthor Shigeyuki Oba
%PMTKdate November 18, 2004
