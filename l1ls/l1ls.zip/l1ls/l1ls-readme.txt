%PMTKtitle l1ls: Interior point methods for L1 regularized least squares
%PMTKauthor Kwangmoo Koh, Seung-Jean Kim, Stephen Boyd
%PMTKurl http://www.stanford.edu/~boyd/l1_ls/
%PMTKdate April 2008

