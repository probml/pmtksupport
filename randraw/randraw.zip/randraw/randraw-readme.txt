%PMTKtitle randraw: efficient random variates generator
%PMTKurl http://www.mathworks.com/matlabcentral/fileexchange/7309
%PMTKauthor Alex Bar-Guy
