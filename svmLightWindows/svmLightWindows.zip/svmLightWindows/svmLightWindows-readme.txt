%PMTKtitle SVMlight: Windows executable
%PMTKauthor Thorsten Joachims 
%PMTKurl http://svmlight.joachims.org/
%PMTKdate August 14, 2008 (Version 6.0.2)
