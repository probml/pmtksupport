%PMTKtitle gpml: Gaussian processes for machine learning
%PMTKauthor Carl Rasmussen, Chris Williams
%PMTKdate  July 25, 2007
%PMTKurl http://www.gaussianprocess.org/gpml/code/matlab/doc/