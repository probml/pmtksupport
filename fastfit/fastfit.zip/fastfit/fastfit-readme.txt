%PMTKurl http://research.microsoft.com/en-us/um/people/minka/software/fastfit/
%PMTKauthor Tom Minka
%PMTKtitle fastfit: routines for computing MLE of Dirichlet and other distributions

