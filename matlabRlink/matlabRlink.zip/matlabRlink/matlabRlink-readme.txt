%PMTKauthor Robert Henson
%PMTKurl http://www.mathworks.com/matlabcentral/fileexchange/5051
%PMTKdate May 2004
%PMTKtitle Matlab R-link: Calling R from Matlab