%PMTKurl http://www.mathworks.com/matlabcentral/fileexchange/29245-boosting-demo
%PMTKauthor Richard Stapenhurst
%PMTKtitle Interactive demo of adaboost applied to some 2d data
