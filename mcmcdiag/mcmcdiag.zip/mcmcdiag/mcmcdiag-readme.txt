%PMTKtitle mcmcdiag: MCMC convergence diagnostics
%PMTKauthor Simo Sarkka  Aki Vehtari
%PMTKurl http://www.lce.hut.fi/research/mm/mcmcdiag/
%PMTKdate 2004

