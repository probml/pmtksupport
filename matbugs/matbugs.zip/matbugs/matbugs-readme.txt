%PMTKauthor Maryam Mahdaviani and Kevin Murphy
%PMTKurl http://code.google.com/p/matbugs/
%PMTKdate August 2005
%PMTKtitle Matbugs: a matlab interface to WinBUGS and OpenBUGS